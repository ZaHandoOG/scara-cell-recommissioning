'======================================================================
' TRANSFERENCIA DE PALLET A -> PALLET B -> PALLET A
'======================================================================
' Pasa las 9 piezas del Pallet A al Pallet B, y luego las regresa al
' Pallet A, cada una a su posici�n original. Corre una sola vez y termina
' en Park.
'======================================================================

#define PALLET_ROWS 3
#define PALLET_COLS 3

Function main
	InitRobot
	
	' Pallet 1 = A, Pallet 2 = B (esquinas ense�adas en el mismo orden)
	Pallet 1, PalA1, PalA2, PalA3, PALLET_COLS, PALLET_ROWS
	Pallet 2, PalB1, PalB2, PalB3, PALLET_COLS, PALLET_ROWS

	' Ida: A -> B
	Print "Transferencia A -> B"
	Transfer 1, 2

	' Regreso: B -> A
	Print "Transferencia B -> A"
	Transfer 2, 1

	Jump Park
	Print "Proceso terminado"
Fend

Function InitRobot
	Reset
	If Motor = Off Then
		Motor On
	EndIf
	Power High
	Speed 40
	Accel 40, 40
	Off GripOn
Fend

Function Transfer(fromPallet As Integer, toPallet As Integer)
	Integer i

	For i = 1 To PALLET_ROWS * PALLET_COLS
		' Toma la pieza de la posici�n i del pallet de origen
		Jump Pallet(fromPallet, i)
		On GripOn
		Wait .1

		' La deja en la misma posici�n i del pallet destino
		Jump Pallet(toPallet, i)
		Off GripOn
		Wait .1

		Print "Pieza ", i, " de ", PALLET_ROWS * PALLET_COLS, " transferida"
	Next i
Fend
