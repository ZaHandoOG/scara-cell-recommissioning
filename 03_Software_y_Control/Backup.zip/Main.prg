Function Main
	Initialize
	MainLoop
Fend

Function Initialize

	' Go to eHandler when an error occurs
	OnErr GoTo eHandler

	' Prepare the program for cycle execution
	Robot 1
	Reset
	Off ErrorLight
	Off InCycle
	Off ReadyLed
	Motor On
	Speed 100
	Accel 100, 100
	' For safety, Power is set to Low for the initial program
	' After program operation verification, Power can be set to High, using caution
	Power High
	Arm 0
	Tool 1
	Jump Park
	Off GripOn

	' Sistema listo para operar
	On ReadyLed
	Exit Function

eHandler:
	' Error processing
	Print "Error", Err, " in function ", Erf$, ", line", Erl, ": ", ErrMsg$(Err)
	Off ReadyLed
	Off InCycle
	On ErrorLight
	Quit All
Fend

Function MainLoop
	Boolean bContinuous

	' Go to eHandler when an error occurs
	OnErr GoTo eHandler

	bContinuous = False

	' Main loop: sondea Start (continuo), Uniq (ciclo �nico) y Stop
	Do
		' --- STOP (StopB, NO): al presionarse, cancela el modo continuo ---
		If StopB = On Then
			bContinuous = False
			Off InCycle
			On ReadyLed
			' Espera a que se libere el bot�n antes de seguir sondeando
			Wait Sw(StopB) = Off
		EndIf

		' --- CICLO �NICO (UniqB, NO): ejecuta un solo ciclo por pulsaci�n ---
		If Sw(UniqB) = On And Sw(StopB) = Off Then
			Off ReadyLed
			On InCycle
			PickAndPlace
			Off InCycle
			On ReadyLed
			' Espera a que se libere el bot�n para no re-disparar el ciclo
			Wait Sw(UniqB) = Off
		EndIf

		' --- CICLO CONTINUO (StartCycle): se mantiene mientras el bot�n est� activo ---
		If Sw(StartCycle) = On And Sw(StopB) = Off Then
			bContinuous = True
		EndIf

		If bContinuous Then
			If Sw(StopB) = Off Then
				Off ReadyLed
				On InCycle
				PickAndPlace
			Else
				bContinuous = False
			EndIf
		EndIf
	Loop

eHandler:
	' Error processing
	Print "Error", Err, " in function ", Erf$, ", line", Erl, ": ", ErrMsg$(Err)
	Off ReadyLed
	Off InCycle
	On ErrorLight
	Quit All
Fend

Function PickAndPlace
	' Ejecuta un solo ciclo completo de pick and place

	' Go to eHandler when an error occurs
	OnErr GoTo eHandler

	' Move the robot to the pick position using jump motion
	Jump Pick
	On GripOn
	' Wait for the part to be gripped
	Wait .1
	' Move the robot to the place position using jump motion
	Jump Place
	Off GripOn
	' Wait for the part to be released
	Wait .1
	Go Park
	Exit Function

eHandler:
	' Error processing
	Print "Error", Err, " in function ", Erf$, ", line", Erl, ": ", ErrMsg$(Err)
	Off ReadyLed
	Off InCycle
	On ErrorLight
	Quit All
Fend
